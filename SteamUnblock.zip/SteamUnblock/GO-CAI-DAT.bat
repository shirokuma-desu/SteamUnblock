@echo off
setlocal EnableDelayedExpansion
title Go cai dat Steam Unblock (zapret)
set "TARGET=C:\zapret"

net session >nul 2>&1
if errorlevel 1 (
  echo Dang xin quyen Administrator...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

cd /d "%TEMP%"
echo Dang dung va xoa service, tac vu kiem tra va driver...
schtasks /delete /tn ZapretWatchdog /f >nul 2>&1
net stop zapret >nul 2>&1
sc delete zapret >nul 2>&1
taskkill /f /im winws.exe >nul 2>&1
net stop WinDivert >nul 2>&1
sc delete WinDivert >nul 2>&1
net stop WinDivert14 >nul 2>&1
sc delete WinDivert14 >nul 2>&1

echo.
choice /c YN /m "Xoa luon thu muc %TARGET% va bo loai tru Windows Defender"
if errorlevel 2 goto :done
powershell -NoProfile -Command "try { Remove-MpPreference -ExclusionPath '%TARGET%' } catch { }" >nul 2>&1
rd /s /q "%TARGET%" >nul 2>&1

:done
echo.
echo Da go xong.
pause
exit /b 0
