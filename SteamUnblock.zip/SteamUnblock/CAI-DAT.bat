@echo off
setlocal EnableDelayedExpansion
title Cai dat Steam Unblock (zapret)
set "TARGET=C:\zapret"
set "SRC=%~dp0"

net session >nul 2>&1
if errorlevel 1 (
  echo Dang xin quyen Administrator...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

if not exist "%SRC%auto_zapret_full.bat" (
  echo Khong thay file auto_zapret_full.bat canh file nay.
  echo Hay GIAI NEN toan bo file zip ra mot thu muc truoc, roi chay lai.
  pause
  exit /b 1
)

echo ================================================
echo  Cong cu nay se:
echo   1. Tai zapret ban Flowseal moi nhat ve %TARGET%
echo   2. Them %TARGET% vao danh sach loai tru cua Windows Defender
echo      vi driver WinDivert hay bi bao nham la virus
echo   3. Them ten mien Steam vao danh sach cua zapret
echo   4. Tu dong tim cau hinh vuot chan Steam va tao service
echo   5. Tao tac vu kiem tra Steam sau moi lan khoi dong may
echo.
echo  Go cai dat bat cu luc nao bang file GO-CAI-DAT.bat
echo ================================================
choice /c YN /m "Tiep tuc cai dat"
if errorlevel 2 exit /b 0

echo.
echo [1/4] Them thu muc %TARGET% vao loai tru cua Windows Defender...
if not exist "%TARGET%" mkdir "%TARGET%"
powershell -NoProfile -Command "try { Add-MpPreference -ExclusionPath '%TARGET%' } catch { }" >nul 2>&1

if exist "%TARGET%\general.bat" (
  echo [2/4] Da co zapret tai %TARGET% - bo qua buoc tai.
  goto :setup
)

echo [2/4] Dang tai ban zapret moi nhat tu GitHub...
set "ZIP=%TEMP%\zapret_flowseal.zip"
del "%ZIP%" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $r=Invoke-RestMethod -Uri 'https://api.github.com/repos/Flowseal/zapret-discord-youtube/releases/latest' -Headers @{'User-Agent'='steam-unblock'}; $a=$r.assets | Where-Object { $_.name -like '*.zip' } | Select-Object -First 1; Invoke-WebRequest -Uri $a.browser_download_url -OutFile '%ZIP%' -UseBasicParsing; exit 0 } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 goto :dlfail
if not exist "%ZIP%" goto :dlfail

powershell -NoProfile -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%TARGET%' -Force"
if errorlevel 1 goto :dlfail
for /d %%d in ("%TARGET%\*") do if exist "%%d\general.bat" (
  xcopy "%%d\*" "%TARGET%\" /e /y /q >nul
  rd /s /q "%%d"
)
if not exist "%TARGET%\general.bat" goto :dlfail
del "%ZIP%" >nul 2>&1

:setup
echo [3/4] Them ten mien Steam vao danh sach zapret...
if not exist "%TARGET%\lists" mkdir "%TARGET%\lists"
set "LISTFILE=%TARGET%\lists\list-general-user.txt"
if not exist "%LISTFILE%" set "LISTFILE=%TARGET%\lists\list-general.txt"
if not exist "%LISTFILE%" type nul > "%LISTFILE%"
>>"%LISTFILE%" echo.
for %%d in (steampowered.com steamcommunity.com steamstatic.com steamcontent.com steam-api.com) do (
  findstr /i /x /c:"%%d" "%LISTFILE%" >nul 2>&1 || >>"%LISTFILE%" echo %%d
)

echo [4/4] Chay bo tu dong tim cau hinh va tao service...
copy /y "%SRC%auto_zapret_full.bat" "%TARGET%\auto_zapret_full.bat" >nul
cd /d "%TARGET%"
call "%TARGET%\auto_zapret_full.bat"
exit /b 0

:dlfail
echo.
echo ################################################
echo  KHONG TAI DUOC zapret tu dong.
echo  Lam thu cong:
echo   1. Vao https://github.com/Flowseal/zapret-discord-youtube/releases
echo   2. Tai file zip ban moi nhat va giai nen vao %TARGET%
echo      sao cho file general.bat nam truc tiep trong %TARGET%
echo   3. Chay lai CAI-DAT.bat
echo ################################################
pause
exit /b 1
