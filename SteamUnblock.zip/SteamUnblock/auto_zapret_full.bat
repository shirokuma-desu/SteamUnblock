@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title Auto zapret: tim file + tao service + watchdog khi khoi dong

rem ================= CAU HINH =================
set "URL=https://store.steampowered.com"
set "WAIT_START=6"
set "TESTS=5"
set "NEED_OK=5"
set "PATTERN=general*.bat"
set "SERVICE=zapret"
set "TASK=ZapretWatchdog"
set "REMOVE_TASK_ON_FAIL=1"
set "LOG=%~dp0zapret_test_log.txt"
set "WLOG=%~dp0zapret_watchdog_log.txt"
set "OK_TXT=zapret_hoat_dong.txt"
set "FAIL_TXT=zapret_khong_hoat_dong.txt"
set "SVC_FAIL_TXT=zapret_service_loi.txt"
set "CMDFILE=%~dp0winws_cmdline.txt"
set "STATE=%~dp0zapret_state.txt"
set "DESKFILE=%~dp0zapret_desktop.txt"
set "SELF=%~f0"
rem ============================================

net session >nul 2>&1
if errorlevel 1 (
  echo Can chay file nay bang quyen Administrator.
  echo Chuot phai file - Run as administrator.
  pause
  exit /b 1
)

where curl.exe >nul 2>&1
if errorlevel 1 (
  echo Khong tim thay curl.exe tren may.
  pause
  exit /b 1
)

if /i "%~1"=="/check" goto :check


rem ##############################################
rem #  CHE DO CAI DAT (chay tay lan dau)         #
rem ##############################################

del "%OK_TXT%" >nul 2>&1
del "%FAIL_TXT%" >nul 2>&1
del "%SVC_FAIL_TXT%" >nul 2>&1
echo Bat dau: %date% %time% > "%LOG%"
set "LOGF=%LOG%"

rem Luu duong dan Desktop cua nguoi dung hien tai (watchdog chay bang SYSTEM can dung cai nay)
set "DESKTOP="
for /f "usebackq delims=" %%d in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"`) do set "DESKTOP=%%d"
if defined DESKTOP >"%DESKFILE%" echo !DESKTOP!

echo Dang don dep service, watchdog va tien trinh cu...
schtasks /delete /tn "%TASK%" /f >nul 2>&1
sc query %SERVICE% >nul 2>&1
if not errorlevel 1 (
  net stop %SERVICE% >nul 2>&1
  sc delete %SERVICE% >nul 2>&1
)
taskkill /f /im goodbyedpi.exe >nul 2>&1
taskkill /f /im winws.exe >nul 2>&1
net stop WinDivert >nul 2>&1
sc delete WinDivert >nul 2>&1
net stop WinDivert14 >nul 2>&1
sc delete WinDivert14 >nul 2>&1
call :sleep 2

set "SKIP="
call :try_bats

if defined found goto :install
goto :nofound


:nofound
taskkill /f /im winws.exe >nul 2>&1
echo.
echo ############################################
echo  THAT BAI: da thu !total! file, khong file nao qua duoc TLS 1.3
echo  Da tao file %FAIL_TXT% trong thu muc zapret va tren Desktop
echo ############################################
>"%FAIL_TXT%" echo ZAPRET KHONG HOAT DONG
>>"%FAIL_TXT%" echo Thoi gian: %date% %time%
>>"%FAIL_TXT%" echo Luc cai dat: da thu !total! file theo mau %PATTERN% nhung khong file nao tra ve 200 on dinh voi TLS 1.3.
>>"%FAIL_TXT%" echo.
>>"%FAIL_TXT%" echo Chi tiet tung file:
type "%LOG%" >> "%FAIL_TXT%"
>>"%LOG%" echo That bai - khong co file hoat dong
call :copy_desktop "%FAIL_TXT%"
pause
exit /b 1


:install
echo.
echo ############################################
echo  TIM THAY FILE HOAT DONG: !found!
echo  Dang tao service %SERVICE% tu dung cau hinh nay...
echo ############################################
>>"%LOG%" echo Tim thay: !found!

set "NEWBAT=!found!"
call :create_service
if not "!svcok!"=="1" goto :svcfail

echo.
echo Service dang chay. Kiem tra lai Steam TLS 1.3 qua service...
call :test_tls
echo     Ket qua: !ok!/%TESTS% lan tra ve 200
if !ok! LSS %NEED_OK% (
  set "svcerr=Service chay nhung TLS 1.3 chi dat !ok!/%TESTS% lan 200"
  goto :svcfail
)

>"%STATE%" echo !found!

echo.
echo Dang tao watchdog kiem tra Steam sau moi lan khoi dong may...
schtasks /create /tn "%TASK%" /tr "\"%SELF%\" /check" /sc onstart /delay 0001:00 /ru SYSTEM /rl HIGHEST /f >nul 2>&1
schtasks /query /tn "%TASK%" >nul 2>&1
if errorlevel 1 (
  echo CANH BAO: khong tao duoc watchdog %TASK%. Service van chay binh thuong.
  set "taskmsg=Watchdog KHONG duoc tao"
) else (
  echo Da tao watchdog %TASK% chay moi lan khoi dong, tre 1 phut.
  set "taskmsg=Watchdog %TASK% da duoc tao, chay sau khi khoi dong 1 phut"
)

echo.
echo ############################################
echo  HOAN TAT
echo  File bat: !found!
echo  Service : %SERVICE% tu chay cung Windows
echo  !taskmsg!
echo  Hay thoat han Steam va mo lai.
echo ############################################
>"%OK_TXT%" echo File bat hoat dong: !found!
>>"%OK_TXT%" echo Service: %SERVICE% da duoc tao, tu khoi dong cung Windows.
>>"%OK_TXT%" echo !taskmsg!
>>"%OK_TXT%" echo Thoi gian: %date% %time%
>>"%OK_TXT%" echo Dong lenh winws dang dung:
type "%CMDFILE%" >> "%OK_TXT%"
>>"%OK_TXT%" echo.
>>"%OK_TXT%" echo Luu y: khong di chuyen hay doi ten thu muc zapret sau khi tao service.
>>"%OK_TXT%" echo Kiem tra watchdog thu cong: schtasks /run /tn %TASK% roi xem zapret_watchdog_log.txt
>>"%OK_TXT%" echo Go het: sc stop %SERVICE% ; sc delete %SERVICE% ; schtasks /delete /tn %TASK% /f
>>"%LOG%" echo Hoan tat: !found! + service %SERVICE% + watchdog
del "%CMDFILE%" >nul 2>&1
pause
exit /b 0


:svcfail
net stop %SERVICE% >nul 2>&1
sc delete %SERVICE% >nul 2>&1
taskkill /f /im winws.exe >nul 2>&1
echo.
echo ############################################
echo  TAO SERVICE THAT BAI: !svcerr!
echo  Da tao file %SVC_FAIL_TXT% trong thu muc zapret va tren Desktop
echo ############################################
>"%SVC_FAIL_TXT%" echo TAO SERVICE ZAPRET THAT BAI
>>"%SVC_FAIL_TXT%" echo Thoi gian: %date% %time%
>>"%SVC_FAIL_TXT%" echo File bat tim thay: !found!
>>"%SVC_FAIL_TXT%" echo Ly do: !svcerr!
>>"%SVC_FAIL_TXT%" echo Cach lam tay: chay file bat tren roi dung service.bat - Install Service.
>>"%LOG%" echo Tao service that bai: !svcerr!
call :copy_desktop "%SVC_FAIL_TXT%"
del "%CMDFILE%" >nul 2>&1
pause
exit /b 1


rem ##############################################
rem #  CHE DO WATCHDOG (tu chay sau khi khoi dong) #
rem ##############################################
:check
>"%WLOG%" echo %date% %time% Watchdog bat dau
set "LOGF=%WLOG%"
set "DESKTOP="
if exist "%DESKFILE%" set /p DESKTOP=<"%DESKFILE%"

rem Cho mang san sang toi da khoang 2 phut
set /a n=0
:waitnet
ping -n 1 -w 1500 1.1.1.1 >nul 2>&1
if not errorlevel 1 goto :netok
ping -n 1 -w 1500 8.8.8.8 >nul 2>&1
if not errorlevel 1 goto :netok
set /a n+=1
if !n! GEQ 24 (
  >>"%WLOG%" echo %date% %time% Mang chua san sang sau 2 phut - bo qua, khong thay doi gi
  exit /b 2
)
call :sleep 5
goto :waitnet

:netok
>>"%WLOG%" echo %date% %time% Mang san sang
call :sleep 10

call :test_tls
>>"%WLOG%" echo %date% %time% Kiem tra lan 1: !ok!/%TESTS% lan 200
if !ok! GEQ %NEED_OK% (
  >>"%WLOG%" echo %date% %time% Service hoat dong tot voi Steam TLS 1.3 - xong
  exit /b 0
)

rem Cho them roi thu lai mot lan truoc khi ket luan
call :sleep 20
call :test_tls
>>"%WLOG%" echo %date% %time% Kiem tra lan 2: !ok!/%TESTS% lan 200
if !ok! GEQ %NEED_OK% (
  >>"%WLOG%" echo %date% %time% Service hoat dong tot voi Steam TLS 1.3 - xong
  exit /b 0
)

>>"%WLOG%" echo %date% %time% Service KHONG qua duoc TLS 1.3 - thu cac file bat con lai
set "current="
if exist "%STATE%" set /p current=<"%STATE%"
>>"%WLOG%" echo %date% %time% File hien tai: !current!

net stop %SERVICE% >nul 2>&1
taskkill /f /im winws.exe >nul 2>&1
call :sleep 2

set "SKIP=!current!"
call :try_bats

if not defined found goto :checkfail

set "NEWBAT=!found!"
call :create_service
if not "!svcok!"=="1" (
  >>"%WLOG%" echo %date% %time% Tao lai service that bai: !svcerr!
  goto :checkfail
)

call :test_tls
>>"%WLOG%" echo %date% %time% Kiem tra sau khi tao lai service: !ok!/%TESTS% lan 200
if !ok! LSS %NEED_OK% goto :checkfail

>"%STATE%" echo !found!
>>"%WLOG%" echo %date% %time% Da chuyen sang file: !found! va tao lai service - xong
del "%CMDFILE%" >nul 2>&1
exit /b 0


:checkfail
net stop %SERVICE% >nul 2>&1
sc config %SERVICE% start= disabled >nul 2>&1
taskkill /f /im winws.exe >nul 2>&1
>>"%WLOG%" echo %date% %time% Het file de thu - da dung va vo hieu hoa service %SERVICE%
>"%FAIL_TXT%" echo ZAPRET KHONG HOAT DONG
>>"%FAIL_TXT%" echo Thoi gian: %date% %time%
>>"%FAIL_TXT%" echo Sau khi khoi dong may, service %SERVICE% khong qua duoc TLS 1.3 voi Steam.
>>"%FAIL_TXT%" echo Da thu cac file bat con lai nhung khong file nao dat. Service da bi dung va vo hieu hoa.
>>"%FAIL_TXT%" echo Neu muon thu lai: chay lai auto_zapret_full.bat bang quyen Administrator.
>>"%FAIL_TXT%" echo.
>>"%FAIL_TXT%" echo Chi tiet:
type "%WLOG%" >> "%FAIL_TXT%"
call :copy_desktop "%FAIL_TXT%"
if "%REMOVE_TASK_ON_FAIL%"=="1" schtasks /delete /tn "%TASK%" /f >nul 2>&1
del "%CMDFILE%" >nul 2>&1
exit /b 1


rem ##############################################
rem #  CAC HAM DUNG CHUNG                         #
rem ##############################################

:sleep
set /a _p=%~1+1
ping -n !_p! 127.0.0.1 >nul
exit /b 0


:test_tls
set /a ok=0
for /l %%i in (1,1,%TESTS%) do (
  set "code=000"
  for /f %%c in ('curl.exe -s -o NUL -w "%%{http_code}" --tlsv1.3 --connect-timeout 5 --max-time 8 %URL% 2^>NUL') do set "code=%%c"
  echo     lan %%i/%TESTS%: HTTP !code!
  if "!code!"=="200" set /a ok+=1
  call :sleep 1
)
exit /b 0


:try_bats
set "found="
set /a total=0
for %%f in (%PATTERN%) do (
  if not defined found (
    if /i not "%%~f"=="!SKIP!" (
      set /a total+=1
      set "cur=%%~f"
      echo.
      echo ============================================
      echo [!total!] Dang thu: !cur!
      echo ============================================
      taskkill /f /im winws.exe >nul 2>&1
      call :sleep 2
      start "zapret_test" /min cmd /c call "!cur!"
      call :sleep %WAIT_START%
      tasklist /fi "imagename eq winws.exe" 2>nul | find /i "winws.exe" >nul
      if errorlevel 1 (
        echo     winws KHONG chay - bo qua file nay
        >>"%LOGF%" echo [!cur!] winws khong chay
      ) else (
        call :test_tls
        echo     Ket qua: !ok!/%TESTS% lan tra ve 200
        >>"%LOGF%" echo [!cur!] !ok!/%TESTS% lan 200
        if !ok! GEQ %NEED_OK% set "found=!cur!"
      )
    )
  )
)
exit /b 0


:create_service
set "svcok=0"
set "svcerr="
del "%CMDFILE%" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'winws.exe' } | Select-Object -First 1 -ExpandProperty CommandLine" > "%CMDFILE%" 2>nul
findstr /i "winws" "%CMDFILE%" >nul 2>&1
if errorlevel 1 (
  set "svcerr=Khong lay duoc dong lenh cua winws.exe de tao service"
  exit /b 1
)
net stop %SERVICE% >nul 2>&1
sc delete %SERVICE% >nul 2>&1
taskkill /f /im winws.exe >nul 2>&1
call :sleep 2
powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=(Get-Content -Raw -LiteralPath '%CMDFILE%').Trim(); New-Service -Name '%SERVICE%' -BinaryPathName $c -DisplayName '%SERVICE%' -StartupType Automatic | Out-Null; Set-Service -Name '%SERVICE%' -Description 'zapret DPI bypass software'; Start-Service -Name '%SERVICE%'" >nul 2>&1
reg add "HKLM\System\CurrentControlSet\Services\%SERVICE%" /v zapret-discord-youtube /t REG_SZ /d "!NEWBAT!" /f >nul 2>&1
call :sleep %WAIT_START%
sc query %SERVICE% | find "RUNNING" >nul 2>&1
if errorlevel 1 (
  set "svcerr=Service %SERVICE% khong o trang thai RUNNING sau khi tao"
  exit /b 1
)
set "svcok=1"
exit /b 0


:copy_desktop
if not defined DESKTOP set "DESKTOP=%PUBLIC%\Desktop"
if not exist "!DESKTOP!\" set "DESKTOP=%PUBLIC%\Desktop"
copy /y "%~1" "!DESKTOP!\%~1" >nul 2>&1
exit /b 0
